def baz():
    print('[mod333] baz()')


class Baz:
    pass