def foo():
    print('[mod111] foo()')

class Foo:
    pass