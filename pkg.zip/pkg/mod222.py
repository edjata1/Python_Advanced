def bar():
    print('[mod222] bar()')


class Bar:
    pass