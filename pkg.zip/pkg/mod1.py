
def foo():
    print('[mod1] foo()')

class Foo:
    pass