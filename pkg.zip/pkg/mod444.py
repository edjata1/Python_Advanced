def qux():
    print('[mod444] qux()')


class Qux:
    pass